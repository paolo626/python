#!/usr/bin/python3

print("hello world!")
print("世界您好！")
